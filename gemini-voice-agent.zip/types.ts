export interface AudioConfig {
  sampleRate: number;
}

export enum AgentStatus {
  DISCONNECTED = 'disconnected',
  CONNECTING = 'connecting',
  CONNECTED = 'connected',
  SPEAKING = 'speaking',
  LISTENING = 'listening',
  ERROR = 'error',
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  sender: 'user' | 'agent' | 'system';
  message: string;
}
