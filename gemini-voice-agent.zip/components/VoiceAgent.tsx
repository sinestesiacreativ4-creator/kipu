import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { AgentStatus, LogEntry } from '../types';
import { createPcmBlob, decodeBase64, decodeAudioData } from '../utils/audioUtils';
import Visualizer from './Visualizer';

// Icons
const MicIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/></svg>
);
const StopIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="6" width="12" height="12" rx="2" ry="2"/></svg>
);
const LoadingIcon = () => (
  <svg className="animate-spin" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
);

const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

const VoiceAgent: React.FC = () => {
  // State
  const [status, setStatus] = useState<AgentStatus>(AgentStatus.DISCONNECTED);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Audio Context Refs
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const inputAnalyserRef = useRef<AnalyserNode | null>(null);
  const outputAnalyserRef = useRef<AnalyserNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const scheduledSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Logic Refs
  const sessionRef = useRef<any>(null); // To store the session object provided by sessionPromise
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const addLog = (message: string, sender: 'system' | 'user' | 'agent') => {
    setLogs((prev) => [
      ...prev,
      { id: Math.random().toString(36).substring(7), timestamp: new Date(), sender, message },
    ]);
  };

  const stopAudioPlayback = useCallback(() => {
    // Stop all currently scheduled sources
    scheduledSourcesRef.current.forEach((source) => {
      try {
        source.stop();
      } catch (e) {
        // ignore errors if source already stopped
      }
    });
    scheduledSourcesRef.current.clear();
    // Reset time cursor
    nextStartTimeRef.current = 0;
  }, []);

  const cleanupAudio = useCallback(() => {
    // 1. Stop processing input
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current.onaudioprocess = null;
      processorRef.current = null;
    }
    if (inputSourceRef.current) {
      inputSourceRef.current.disconnect();
      inputSourceRef.current = null;
    }
    
    // 2. Stop microphone stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }

    // 3. Close Audio Contexts
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    
    inputAnalyserRef.current = null;
    outputAnalyserRef.current = null;
    
    stopAudioPlayback();
  }, [stopAudioPlayback]);

  const disconnectSession = useCallback(async () => {
    setStatus(AgentStatus.DISCONNECTED);
    
    if (sessionRef.current) {
      try {
         // The SDK doesn't always expose a clean close on the session object depending on version,
         // but we can assume letting it drop or cleaning up resources is enough.
         // If close exists: sessionRef.current.close();
      } catch (e) {
        console.error("Error closing session", e);
      }
      sessionRef.current = null;
    }
    
    cleanupAudio();
    addLog('Sesión finalizada.', 'system');
  }, [cleanupAudio]);

  const startSession = async () => {
    try {
      setError(null);
      setStatus(AgentStatus.CONNECTING);
      addLog('Iniciando conexión con Gemini...', 'system');

      // 1. Initialize Audio Contexts
      // Input: 16kHz for Gemini
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      // Output: 24kHz for playback quality
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;

      // 2. Setup Analysers for Visualization
      const inputAnalyser = inputCtx.createAnalyser();
      inputAnalyser.fftSize = 256;
      inputAnalyserRef.current = inputAnalyser;

      const outputAnalyser = outputCtx.createAnalyser();
      outputAnalyser.fftSize = 256;
      outputAnalyserRef.current = outputAnalyser;

      // 3. Get Microphone Access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 4. Connect to Gemini Live API
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: 'Eres un asistente útil, amable y conciso que habla español. Tu objetivo es ayudar al usuario de manera eficiente.',
        },
        callbacks: {
          onopen: () => {
            addLog('Conectado. ¡Habla ahora!', 'system');
            setStatus(AgentStatus.CONNECTED);

            // Setup Audio Pipeline strictly AFTER connection opens
            const source = inputCtx.createMediaStreamSource(stream);
            inputSourceRef.current = source;
            
            // Connect source to analyser for visualization
            source.connect(inputAnalyser);

            // Use ScriptProcessor for raw PCM capture (Legacy but standard for this API usage in browser)
            // Buffer size 4096 gives a balance between latency and performance
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              
              // Send to Gemini
              sessionPromise.then((session) => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            // Connect graph: Source -> Analyser -> Processor -> Destination (Mute local)
            // Note: We don't connect to inputCtx.destination to avoid hearing ourselves
            source.connect(processor);
            processor.connect(inputCtx.destination); 
          },
          onmessage: async (message: LiveServerMessage) => {
            // Handle Audio from Model
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            
            if (audioData && outputAudioContextRef.current) {
               // Update status visual
               setStatus(AgentStatus.SPEAKING);

               const ctx = outputAudioContextRef.current;
               
               // Ensure playback timing is continuous
               nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);

               try {
                 const audioBuffer = await decodeAudioData(
                   decodeBase64(audioData),
                   ctx,
                   24000,
                   1
                 );

                 const source = ctx.createBufferSource();
                 source.buffer = audioBuffer;
                 
                 // Connect to analyser then to speakers
                 if (outputAnalyserRef.current) {
                    source.connect(outputAnalyserRef.current);
                    outputAnalyserRef.current.connect(ctx.destination);
                 } else {
                    source.connect(ctx.destination);
                 }

                 source.addEventListener('ended', () => {
                   scheduledSourcesRef.current.delete(source);
                   if (scheduledSourcesRef.current.size === 0) {
                     setStatus(AgentStatus.CONNECTED); // Back to idle/listening
                   }
                 });

                 source.start(nextStartTimeRef.current);
                 scheduledSourcesRef.current.add(source);
                 
                 nextStartTimeRef.current += audioBuffer.duration;
               } catch (err) {
                 console.error("Error decoding audio chunk", err);
               }
            }

            // Handle Interruption
            if (message.serverContent?.interrupted) {
              addLog('Interrumpido por el usuario.', 'system');
              stopAudioPlayback();
              setStatus(AgentStatus.LISTENING);
            }
            
            // Handle Turn Complete (optional for logging)
            if (message.serverContent?.turnComplete) {
              // turn completed
            }
          },
          onclose: () => {
            addLog('Conexión cerrada por el servidor.', 'system');
            disconnectSession();
          },
          onerror: (err) => {
            console.error(err);
            setError('Error de conexión o API.');
            disconnectSession();
          }
        }
      });

      // Store the session for later cleanup
      sessionRef.current = await sessionPromise;

    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error al iniciar la sesión.');
      setStatus(AgentStatus.ERROR);
      cleanupAudio();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-black p-4 text-slate-100">
      
      <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[600px]">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-700 bg-slate-950/50">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
              Gemini Voice Agent
            </h1>
            <div className={`flex items-center gap-2 px-2 py-1 rounded-full text-xs font-medium ${
              status === AgentStatus.CONNECTED || status === AgentStatus.SPEAKING 
                ? 'bg-green-500/20 text-green-400' 
                : status === AgentStatus.ERROR 
                  ? 'bg-red-500/20 text-red-400'
                  : 'bg-slate-700 text-slate-400'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                status === AgentStatus.CONNECTED || status === AgentStatus.SPEAKING ? 'bg-green-400 animate-pulse' : 'bg-current'
              }`} />
              {status === AgentStatus.DISCONNECTED ? 'Desconectado' : 
               status === AgentStatus.CONNECTING ? 'Conectando...' : 
               status === AgentStatus.SPEAKING ? 'Hablando' : 'En Línea'}
            </div>
          </div>
        </div>

        {/* Visualizers Area */}
        <div className="flex-1 p-6 flex flex-col gap-4 justify-center relative">
          
          {/* Output Visualizer (Agent) */}
          <div className="relative">
             <span className="absolute top-2 left-2 text-xs font-medium text-blue-400 z-10">Agente</span>
             <Visualizer 
                analyser={outputAnalyserRef.current} 
                isActive={status === AgentStatus.SPEAKING} 
                color="#60a5fa" 
             />
          </div>

          {/* Input Visualizer (User) */}
          <div className="relative">
             <span className="absolute top-2 left-2 text-xs font-medium text-emerald-400 z-10">Tú (Micrófono)</span>
             <Visualizer 
                analyser={inputAnalyserRef.current} 
                isActive={status === AgentStatus.CONNECTED || status === AgentStatus.LISTENING || status === AgentStatus.SPEAKING} 
                color="#34d399" 
             />
          </div>

        </div>

        {/* Logs / Feedback Area */}
        <div className="h-48 bg-slate-950/30 p-4 border-t border-slate-800 overflow-y-auto scrollbar-hide font-mono text-sm" ref={scrollRef}>
          {logs.length === 0 && (
            <div className="text-slate-500 text-center italic mt-10">
              Listo para conversar. Presiona el micrófono.
            </div>
          )}
          {logs.map((log) => (
            <div key={log.id} className={`mb-2 ${
              log.sender === 'system' ? 'text-slate-500 italic' : 
              log.sender === 'user' ? 'text-emerald-400' : 'text-blue-400'
            }`}>
              <span className="opacity-50 text-xs mr-2">[{log.timestamp.toLocaleTimeString()}]</span>
              {log.message}
            </div>
          ))}
          {error && (
            <div className="text-red-400 font-medium mt-2 p-2 bg-red-900/20 rounded border border-red-800">
              Error: {error}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="p-6 bg-slate-950/50 border-t border-slate-700 flex justify-center items-center gap-4">
           {status === AgentStatus.DISCONNECTED || status === AgentStatus.ERROR || status === AgentStatus.CONNECTING ? (
             <button
               onClick={startSession}
               disabled={status === AgentStatus.CONNECTING}
               className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-lg hover:shadow-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed"
             >
               {status === AgentStatus.CONNECTING ? <LoadingIcon /> : <MicIcon />}
               <span className="absolute -top-10 scale-0 group-hover:scale-100 transition-transform bg-slate-800 text-white text-xs py-1 px-2 rounded">
                 Iniciar
               </span>
             </button>
           ) : (
             <button
               onClick={disconnectSession}
               className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white transition-all shadow-lg hover:shadow-red-500/30"
             >
               <StopIcon />
               <span className="absolute -top-10 scale-0 group-hover:scale-100 transition-transform bg-slate-800 text-white text-xs py-1 px-2 rounded">
                 Detener
               </span>
             </button>
           )}
        </div>

      </div>
      
      <div className="mt-6 text-slate-500 text-xs max-w-sm text-center">
        <p>Asegúrate de usar auriculares para evitar eco.</p>
        <p className="mt-1">Potenciado por Gemini 2.5 Flash Native Audio</p>
      </div>

    </div>
  );
};

export default VoiceAgent;