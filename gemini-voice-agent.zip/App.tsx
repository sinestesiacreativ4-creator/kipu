import React from 'react';
import VoiceAgent from './components/VoiceAgent';

const App: React.FC = () => {
  return (
    <div className="w-full min-h-screen">
      <VoiceAgent />
    </div>
  );
};

export default App;