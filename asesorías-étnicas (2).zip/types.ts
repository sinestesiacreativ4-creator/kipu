export enum RecordingStatus {
  IDLE = 'IDLE',
  RECORDING = 'RECORDING',
  PAUSED = 'PAUSED',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface TranscriptSegment {
  speaker: string;
  text: string;
  timestamp: string; // "MM:SS"
}

export interface AIAnalysis {
  title: string;
  summary: string[];
  actionItems: string[];
  transcript: TranscriptSegment[];
  category: string;
  tags: string[];
}

export interface Marker {
  id: string;
  timestamp: number; // seconds
  label: string;
}

export interface Recording {
  id: string;
  userId: string; // Linked to specific user
  audioBlob?: Blob; // Non-persistent in this demo storage, usually upload to S3
  audioBase64?: string; // For local storage demo
  duration: number; // seconds
  createdAt: number; // Date.now()
  status: RecordingStatus;
  analysis?: AIAnalysis;
  markers: Marker[];
}

export interface UserProfile {
  id: string;
  name: string;
  role: string; // e.g., "Abogada", "Facilitador", "Lonko"
  avatarColor: string;
}

export interface ExportOptions {
  includeSummary: boolean;
  includeTranscript: boolean;
  includeActionItems: boolean;
}