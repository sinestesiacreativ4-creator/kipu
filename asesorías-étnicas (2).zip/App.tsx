import React, { useState, useEffect } from 'react';
import { Mic, Search, Clock, FileAudio, LogOut, Trash2, Loader2 } from 'lucide-react';
import Recorder from './components/Recorder';
import DetailView from './components/DetailView';
import ProfileSelector from './components/ProfileSelector';
import { Recording, RecordingStatus, Marker, UserProfile } from './types';
import { blobToBase64, formatTime, generateId } from './utils';
import { analyzeAudio } from './services/geminiService';
import { db } from './services/db';

// --- Components defined inline for simplicity of the file structure ---

const Dashboard = ({ 
  recordings, 
  user,
  onStartRecord, 
  onSelectRecording,
  onDeleteRecording
}: { 
  recordings: Recording[], 
  user: UserProfile,
  onStartRecord: () => void, 
  onSelectRecording: (r: Recording) => void,
  onDeleteRecording: (id: string) => void
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecordings = recordings.filter(r => {
    const term = searchTerm.toLowerCase();
    return r.analysis?.title.toLowerCase().includes(term) || 
           r.analysis?.category.toLowerCase().includes(term) ||
           r.analysis?.tags.some(t => t.toLowerCase().includes(term));
  });

  return (
    <div className="max-w-5xl mx-auto p-6 md:p-10 animate-fade-in">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 dark:text-white tracking-tight">
            Mari Mari, {user.name}
          </h1>
          <p className="text-stone-500 dark:text-stone-400 mt-1">
            {recordings.length === 0 
              ? 'No tienes grabaciones aún.' 
              : `Tienes ${recordings.length} documentos en tu archivo.`}
          </p>
        </div>
        <div className="relative w-full md:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
          <input 
            type="text" 
            placeholder="Buscar palabras clave..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full md:w-80 pl-10 pr-4 py-2.5 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-full focus:outline-none focus:ring-2 focus:ring-secondary text-sm transition-shadow"
          />
        </div>
      </header>

      {/* Recent Section */}
      <section>
        <h2 className="text-lg font-semibold text-stone-800 dark:text-stone-200 mb-4">Grabaciones Recientes</h2>
        
        {filteredRecordings.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-stone-900 rounded-2xl border-2 border-dashed border-stone-200 dark:border-stone-800">
            <div className="w-16 h-16 bg-stone-50 dark:bg-stone-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileAudio className="text-stone-300 dark:text-stone-600" size={32} />
            </div>
            <p className="text-stone-500 dark:text-stone-400">Tu archivo está vacío. Comienza a documentar una sesión.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredRecordings.map(rec => (
              <div 
                key={rec.id} 
                className="group bg-white dark:bg-stone-900 p-5 rounded-2xl border border-stone-100 dark:border-stone-800 hover:shadow-xl hover:border-primary/30 transition-all relative overflow-hidden"
              >
                <div onClick={() => onSelectRecording(rec)} className="cursor-pointer">
                  <div className="flex justify-between items-start mb-4">
                    <div className={`p-2 rounded-lg ${rec.status === RecordingStatus.PROCESSING ? 'bg-yellow-100 text-yellow-600' : 'bg-stone-100 dark:bg-stone-800 text-secondary'}`}>
                      {rec.status === RecordingStatus.PROCESSING ? <Clock size={20} className="animate-spin-slow"/> : <FileAudio size={20}/>}
                    </div>
                    <span className="text-xs text-stone-400 font-mono">{formatTime(rec.duration)}</span>
                  </div>
                  
                  <h3 className="font-bold text-stone-900 dark:text-stone-100 mb-1 line-clamp-1">
                    {rec.analysis?.title || "Procesando..."}
                  </h3>
                  <p className="text-sm text-stone-500 dark:text-stone-400 mb-4 line-clamp-2 h-10">
                    {rec.analysis?.summary?.[0] || "Esperando resumen de IA..."}
                  </p>

                  <div className="flex items-center gap-2 mt-auto">
                    <span className="px-2 py-1 bg-stone-100 dark:bg-stone-800 text-xs text-stone-500 dark:text-stone-400 rounded-md">
                      {rec.analysis?.category || "Sin categoría"}
                    </span>
                    <span className="text-xs text-stone-400 ml-auto">
                      {new Date(rec.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Delete Button */}
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    if(confirm('¿Estás seguro de que deseas eliminar esta grabación?')) {
                      onDeleteRecording(rec.id);
                    }
                  }}
                  className="absolute top-4 right-4 p-1.5 text-stone-300 hover:text-red-500 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* FAB */}
      <button 
        onClick={onStartRecord}
        className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-primary hover:bg-primary-hover text-white p-4 rounded-full shadow-2xl shadow-primary/40 transition-transform hover:scale-110 active:scale-95 flex items-center gap-2 pr-6 z-30"
      >
        <div className="bg-white/20 p-2 rounded-full">
          <Mic size={24} />
        </div>
        <span className="font-semibold text-lg">Iniciar Sesión</span>
      </button>
    </div>
  );
};

// --- Main App Component ---

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [view, setView] = useState<'dashboard' | 'recorder' | 'detail'>('dashboard');
  const [recordings, setRecordings] = useState<Recording[]>([]);
  const [selectedRecordingId, setSelectedRecordingId] = useState<string | null>(null);
  
  // Initial DB Load
  useEffect(() => {
    const init = async () => {
      try {
        const fetchedProfiles = await db.getProfiles();
        if (fetchedProfiles.length > 0) {
          setProfiles(fetchedProfiles);
        } else {
          // Seed default profiles if DB is empty
          const defaults: UserProfile[] = [
            { id: '1', name: 'Rayen', role: 'Abogada DDHH', avatarColor: 'bg-red-600' },
            { id: '2', name: 'Nahuel', role: 'Facilitador', avatarColor: 'bg-green-700' },
            { id: '3', name: 'Aylin', role: 'Consejera', avatarColor: 'bg-amber-600' },
          ];
          // Save defaults one by one
          for (const p of defaults) {
            await db.addProfile(p);
          }
          setProfiles(defaults);
        }
      } catch (err) {
        console.error("Failed to initialize DB:", err);
      } finally {
        setIsLoading(false);
      }
    };
    
    init();
  }, []);

  // Load recordings when user changes
  useEffect(() => {
    if (currentUser) {
      const loadUserRecordings = async () => {
        try {
          const userRecordings = await db.getRecordings(currentUser.id);
          setRecordings(userRecordings);
        } catch (err) {
          console.error("Error loading recordings:", err);
        }
      };
      loadUserRecordings();
      setView('dashboard');
    } else {
      setRecordings([]);
    }
  }, [currentUser]);

  const handleCreateProfile = async (profile: UserProfile) => {
    try {
      await db.addProfile(profile);
      setProfiles(prev => [...prev, profile]);
      setCurrentUser(profile);
    } catch (err) {
      console.error("Error creating profile:", err);
      alert("Error al crear el perfil.");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setRecordings([]);
    setSelectedRecordingId(null);
  };

  const handleDeleteRecording = async (id: string) => {
    try {
      await db.deleteRecording(id);
      setRecordings(prev => prev.filter(r => r.id !== id));
      if (selectedRecordingId === id) {
        setSelectedRecordingId(null);
        setView('dashboard');
      }
    } catch (err) {
      console.error("Error deleting recording:", err);
      alert("No se pudo eliminar la grabación.");
    }
  };

  const handleRecordingComplete = async (blob: Blob, duration: number, markers: Marker[]) => {
    if (!currentUser) return;

    const id = generateId();
    const base64 = await blobToBase64(blob);

    // 1. Create initial recording entry
    const newRecording: Recording = {
      id,
      userId: currentUser.id,
      audioBase64: base64,
      duration,
      createdAt: Date.now(),
      status: RecordingStatus.PROCESSING,
      markers,
      analysis: { // Temporary placeholder
        title: "Nueva Grabación...",
        category: "Procesando",
        summary: ["Procesando audio..."],
        actionItems: [],
        transcript: [],
        tags: []
      }
    };

    // Optimistic update
    setRecordings(prev => [newRecording, ...prev]);
    setSelectedRecordingId(id);
    setView('detail');

    // Async Save to DB
    try {
      await db.saveRecording(newRecording);
    } catch (err) {
      console.error("Failed to save initial recording:", err);
    }

    // 2. Trigger AI Processing
    try {
      const analysis = await analyzeAudio(base64, markers.length);
      
      const updatedRecording = {
        ...newRecording,
        status: RecordingStatus.COMPLETED,
        analysis
      };

      // Update state
      setRecordings(prev => prev.map(rec => rec.id === id ? updatedRecording : rec));
      
      // Update DB
      await db.saveRecording(updatedRecording);

    } catch (error) {
      console.error("AI Processing Failed", error);
      
      const errorRecording = {
        ...newRecording,
        status: RecordingStatus.ERROR,
        analysis: {
          ...newRecording.analysis!,
          title: "Error de Procesamiento",
          summary: ["Falló el procesamiento del audio con IA."]
        }
      };

      setRecordings(prev => prev.map(rec => rec.id === id ? errorRecording : rec));
      await db.saveRecording(errorRecording);
    }
  };

  const activeRecording = recordings.find(r => r.id === selectedRecordingId);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bone dark:bg-darkbg text-stone-600 dark:text-stone-400">
         <div className="flex flex-col items-center">
            <Loader2 className="w-10 h-10 animate-spin mb-4 text-primary" />
            <p>Cargando base de datos...</p>
         </div>
      </div>
    );
  }

  // --- Auth Gate ---
  if (!currentUser) {
    return (
      <ProfileSelector 
        profiles={profiles} 
        onSelect={setCurrentUser} 
        onCreate={handleCreateProfile} 
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-bone dark:bg-darkbg text-stone-800 dark:text-stone-200 transition-colors duration-200">
      {/* Navbar */}
      <nav className="h-16 border-b border-stone-200 dark:border-stone-800 flex items-center px-6 bg-white dark:bg-stone-900 sticky top-0 z-40 no-print shadow-sm">
        <div className="flex items-center gap-3 text-2xl font-bold tracking-tighter cursor-pointer hover:opacity-80 transition-opacity" onClick={() => setView('dashboard')}>
          <div className="w-8 h-8 wiphala-gradient rounded-md flex items-center justify-center text-white shadow-sm">
            <Mic size={18} strokeWidth={3} />
          </div>
          <span className="text-stone-900 dark:text-white tracking-tight hidden sm:block">Asesorías <span className="text-primary font-extrabold">Étnicas</span></span>
        </div>
        
        <div className="ml-auto flex items-center gap-4">
           {/* User Profile Badge */}
           <div className="flex items-center gap-3 pl-4 border-l border-stone-200 dark:border-stone-700">
             <div className="text-right hidden sm:block">
               <p className="text-sm font-bold text-stone-900 dark:text-white leading-none">{currentUser.name}</p>
               <p className="text-xs text-stone-500 dark:text-stone-400">{currentUser.role}</p>
             </div>
             <div className={`w-9 h-9 rounded-full ${currentUser.avatarColor} flex items-center justify-center text-white font-bold shadow-sm border-2 border-white dark:border-stone-800`}>
               {currentUser.name.charAt(0).toUpperCase()}
             </div>
             <button 
               onClick={handleLogout}
               className="p-2 text-stone-400 hover:text-red-600 dark:hover:text-red-400 transition-colors"
               title="Cerrar Sesión"
             >
               <LogOut size={18} />
             </button>
           </div>
        </div>
      </nav>

      <main className="flex-1 relative">
        {view === 'dashboard' && (
          <Dashboard 
            recordings={recordings} 
            user={currentUser}
            onStartRecord={() => setView('recorder')} 
            onSelectRecording={(rec) => {
              setSelectedRecordingId(rec.id);
              setView('detail');
            }}
            onDeleteRecording={handleDeleteRecording}
          />
        )}

        {view === 'recorder' && (
          <Recorder 
            onComplete={handleRecordingComplete} 
            onCancel={() => setView('dashboard')} 
          />
        )}

        {view === 'detail' && activeRecording && (
          <DetailView 
            recording={activeRecording} 
            onBack={() => {
              setSelectedRecordingId(null);
              setView('dashboard');
            }} 
          />
        )}
      </main>
    </div>
  );
}