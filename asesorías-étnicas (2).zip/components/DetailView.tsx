import React, { useState, useRef } from 'react';
import { ArrowLeft, List, Download, Folder, CheckCircle2 } from 'lucide-react';
import { Recording, RecordingStatus, ExportOptions } from '../types';
import { formatTime } from '../utils';

interface DetailViewProps {
  recording: Recording;
  onBack: () => void;
}

const DetailView: React.FC<DetailViewProps> = ({ recording, onBack }) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'transcript'>('summary');
  const [showExportModal, setShowExportModal] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [exportOpts, setExportOpts] = useState<ExportOptions>({
    includeSummary: true,
    includeTranscript: true,
    includeActionItems: true
  });

  const { analysis, duration, createdAt, audioBase64 } = recording;

  const handleExport = () => {
    window.print();
    setShowExportModal(false);
  };

  if (recording.status === RecordingStatus.PROCESSING) {
    return (
      <div className="flex flex-col items-center justify-center h-screen text-center p-8">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-6"></div>
        <h2 className="text-2xl font-bold mb-2">La IA está procesando el audio...</h2>
        <p className="text-stone-500">Identificando hablantes, resumiendo puntos clave y extrayendo tareas.</p>
      </div>
    );
  }

  if (!analysis) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl text-red-500">Error: Faltan datos de análisis.</h2>
        <button onClick={onBack} className="mt-4 text-primary underline">Volver Atrás</button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-8 print:p-0 print:max-w-none">
      {/* Header */}
      <header className="mb-8 no-print">
        <button 
          onClick={onBack} 
          className="flex items-center text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-white mb-4 transition-colors"
        >
          <ArrowLeft size={18} className="mr-2" /> Volver al Inicio
        </button>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-stone-900 dark:text-white mb-2">{analysis.title}</h1>
            <div className="flex flex-wrap items-center gap-3 text-sm text-stone-500 dark:text-stone-400">
              <span className="flex items-center gap-1"><Folder size={14}/> {analysis.category}</span>
              <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
              <span>{new Date(createdAt).toLocaleDateString()}</span>
              <span className="w-1 h-1 bg-stone-300 rounded-full"></span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => setShowExportModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-secondary hover:bg-green-800 text-white rounded-lg shadow transition-all"
            >
              <Download size={18} /> Exportar PDF
            </button>
          </div>
        </div>
      </header>

      {/* Print Only Header */}
      <div className="hidden print-only mb-8">
        <h1 className="text-4xl font-bold mb-2">{analysis.title}</h1>
        <p className="text-stone-600 mb-4">Fecha: {new Date(createdAt).toLocaleDateString()} | Duración: {formatTime(duration)}</p>
        <hr className="border-stone-300"/>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Tabs (No Print) */}
          <div className="flex border-b border-stone-200 dark:border-stone-700 no-print">
            <button
              onClick={() => setActiveTab('summary')}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'summary' 
                  ? 'border-primary text-primary' 
                  : 'border-transparent text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200'
              }`}
            >
              Resumen Inteligente
            </button>
            <button
              onClick={() => setActiveTab('transcript')}
              className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                activeTab === 'transcript' 
                  ? 'border-primary text-primary' 
                  : 'border-transparent text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200'
              }`}
            >
              Transcripción Completa
            </button>
          </div>

          {/* Summary Tab Content */}
          <div className={`${activeTab === 'summary' ? 'block' : 'hidden'} print:block space-y-8 animate-fade-in`}>
            
            <section className="bg-white dark:bg-stone-800 p-6 rounded-xl shadow-sm border border-stone-100 dark:border-stone-700">
              <h3 className="flex items-center gap-2 text-lg font-semibold text-stone-900 dark:text-white mb-4">
                <List className="text-secondary" size={20}/> Puntos Clave
              </h3>
              <ul className="space-y-3">
                {analysis.summary.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-stone-700 dark:text-stone-300 leading-relaxed">
                    <span className="mt-1.5 w-1.5 h-1.5 bg-primary rounded-full flex-shrink-0"></span>
                    {point}
                  </li>
                ))}
              </ul>
            </section>

            <section className="bg-white dark:bg-stone-800 p-6 rounded-xl shadow-sm border border-stone-100 dark:border-stone-700">
              <h3 className="flex items-center gap-2 text-lg font-semibold text-stone-900 dark:text-white mb-4">
                <CheckCircle2 className="text-secondary" size={20}/> Tareas Pendientes
              </h3>
              {analysis.actionItems.length > 0 ? (
                <ul className="space-y-3">
                  {analysis.actionItems.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-3 p-3 bg-stone-50 dark:bg-stone-700/50 rounded-lg border border-stone-100 dark:border-stone-600">
                      <div className="w-5 h-5 border-2 border-stone-300 rounded flex-shrink-0"></div>
                      <span className="text-stone-800 dark:text-stone-200">{item}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-stone-500 italic">No se detectaron tareas específicas.</p>
              )}
            </section>

          </div>

          {/* Transcript Tab Content */}
          <div className={`${activeTab === 'transcript' ? 'block' : 'hidden'} print:block animate-fade-in`}>
            <div className="bg-white dark:bg-stone-800 rounded-xl shadow-sm border border-stone-100 dark:border-stone-700 divide-y divide-stone-100 dark:divide-stone-700">
              {analysis.transcript.map((segment, idx) => (
                <div key={idx} className="p-4 hover:bg-stone-50 dark:hover:bg-stone-700/30 transition-colors group">
                  <div className="flex justify-between items-baseline mb-1">
                    <span className="font-semibold text-sm text-secondary">{segment.speaker}</span>
                    <span className="text-xs text-stone-400 font-mono group-hover:text-stone-600">{segment.timestamp}</span>
                  </div>
                  <p className="text-stone-700 dark:text-stone-300 leading-relaxed">{segment.text}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Sidebar / Sticky Player */}
        <div className="lg:col-span-1 space-y-6">
          {/* Audio Player */}
          <div className="sticky top-6 bg-white dark:bg-stone-800 p-6 rounded-xl shadow-lg border border-stone-100 dark:border-stone-700 no-print">
            <h3 className="text-sm font-semibold text-stone-500 dark:text-stone-400 uppercase tracking-wider mb-4">Grabación</h3>
            {audioBase64 && (
              <audio 
                ref={audioRef} 
                controls 
                className="w-full mb-4 accent-primary"
                src={`data:audio/webm;base64,${audioBase64}`} 
              />
            )}
            
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-stone-900 dark:text-white mb-3">Etiquetas</h4>
              <div className="flex flex-wrap gap-2">
                {analysis.tags.map((tag, idx) => (
                  <span key={idx} className="px-2 py-1 bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 text-xs rounded-md border border-stone-200 dark:border-stone-600">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

             <div className="mt-6">
              <h4 className="text-sm font-semibold text-stone-900 dark:text-white mb-3">Hablantes</h4>
              <div className="space-y-2">
                {[...new Set(analysis.transcript.map(t => t.speaker))].map((speaker, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-stone-600 dark:text-stone-400">
                    <div className={`w-2 h-2 rounded-full ${idx === 0 ? 'bg-blue-400' : 'bg-amber-500'}`}></div>
                    {speaker}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-stone-900 rounded-2xl shadow-2xl max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-xl font-bold text-stone-900 dark:text-white mb-4">Opciones de Exportación</h3>
            <p className="text-stone-500 dark:text-stone-400 text-sm mb-6">Selecciona qué deseas incluir en tu documento PDF.</p>
            
            <div className="space-y-3 mb-8">
              <label className="flex items-center gap-3 p-3 rounded-lg border border-stone-200 dark:border-stone-700 cursor-pointer hover:bg-stone-50 dark:hover:bg-stone-800">
                <input 
                  type="checkbox" 
                  checked={exportOpts.includeSummary}
                  onChange={e => setExportOpts({...exportOpts, includeSummary: e.target.checked})}
                  className="w-5 h-5 text-primary rounded focus:ring-primary"
                />
                <span className="text-stone-700 dark:text-stone-200">Resumen Ejecutivo</span>
              </label>
              <label className="flex items-center gap-3 p-3 rounded-lg border border-stone-200 dark:border-stone-700 cursor-pointer hover:bg-stone-50 dark:hover:bg-stone-800">
                <input 
                  type="checkbox" 
                  checked={exportOpts.includeActionItems}
                  onChange={e => setExportOpts({...exportOpts, includeActionItems: e.target.checked})}
                  className="w-5 h-5 text-primary rounded focus:ring-primary"
                />
                <span className="text-stone-700 dark:text-stone-200">Lista de Tareas</span>
              </label>
              <label className="flex items-center gap-3 p-3 rounded-lg border border-stone-200 dark:border-stone-700 cursor-pointer hover:bg-stone-50 dark:hover:bg-stone-800">
                <input 
                  type="checkbox" 
                  checked={exportOpts.includeTranscript}
                  onChange={e => setExportOpts({...exportOpts, includeTranscript: e.target.checked})}
                  className="w-5 h-5 text-primary rounded focus:ring-primary"
                />
                <span className="text-stone-700 dark:text-stone-200">Transcripción Completa</span>
              </label>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setShowExportModal(false)}
                className="flex-1 px-4 py-2 text-stone-600 hover:bg-stone-100 dark:text-stone-300 dark:hover:bg-stone-800 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={handleExport}
                className="flex-1 px-4 py-2 bg-primary hover:bg-primary-hover text-white rounded-lg font-medium shadow-lg shadow-primary/20 transition-all"
              >
                Generar PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DetailView;