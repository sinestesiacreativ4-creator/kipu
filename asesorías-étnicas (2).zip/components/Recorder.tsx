import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Square, Pause, Play, Flag } from 'lucide-react';
import Waveform from './Waveform';
import { RecordingStatus, Marker } from '../types';
import { formatTime } from '../utils';

interface RecorderProps {
  onComplete: (blob: Blob, duration: number, markers: Marker[]) => void;
  onCancel: () => void;
}

const Recorder: React.FC<RecorderProps> = ({ onComplete, onCancel }) => {
  const [status, setStatus] = useState<RecordingStatus>(RecordingStatus.IDLE);
  const [duration, setDuration] = useState(0);
  const [markers, setMarkers] = useState<Marker[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const startRecording = async () => {
    try {
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setStream(audioStream);
      
      const mediaRecorder = new MediaRecorder(audioStream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.start();
      setStatus(RecordingStatus.RECORDING);
      
      // Start Timer
      timerRef.current = window.setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);

    } catch (error) {
      console.error("Error accessing microphone:", error);
      alert("No se pudo acceder al micrófono. Por favor verifique los permisos.");
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.pause();
      setStatus(RecordingStatus.PAUSED);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'paused') {
      mediaRecorderRef.current.resume();
      setStatus(RecordingStatus.RECORDING);
      timerRef.current = window.setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    }
  };

  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      if (timerRef.current) clearInterval(timerRef.current);
      
      // Wait for the last data chunk
      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        // Clean up stream tracks
        stream?.getTracks().forEach(track => track.stop());
        setStream(null);
        setStatus(RecordingStatus.COMPLETED);
        onComplete(blob, duration, markers);
      };
    }
  }, [duration, markers, onComplete, stream]);

  const addMarker = () => {
    setMarkers([...markers, { 
      id: Date.now().toString(), 
      timestamp: duration, 
      label: `Marca en ${formatTime(duration)}` 
    }]);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (stream) stream.getTracks().forEach(track => track.stop());
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Initial start
  useEffect(() => {
    startRecording();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] w-full max-w-3xl mx-auto p-6 animate-fade-in">
      {/* Timer Display */}
      <div className="text-6xl font-mono font-bold text-stone-800 dark:text-stone-100 mb-8 tracking-tighter">
        {formatTime(duration)}
      </div>

      {/* Waveform Visualization */}
      <div className="w-full mb-12 bg-stone-100 dark:bg-stone-800/50 rounded-xl overflow-hidden border border-stone-200 dark:border-stone-700 shadow-inner">
        <Waveform stream={stream} isRecording={status === RecordingStatus.RECORDING} />
      </div>

      {/* Controls Container */}
      <div className="flex items-center gap-8">
        
        {/* Marker Button */}
        <button 
          onClick={addMarker}
          disabled={status !== RecordingStatus.RECORDING}
          className={`p-4 rounded-full transition-all duration-200 border-2 ${
            status === RecordingStatus.RECORDING 
            ? 'border-stone-300 text-stone-600 hover:bg-stone-100 dark:border-stone-600 dark:text-stone-300 dark:hover:bg-stone-700' 
            : 'border-stone-200 text-stone-300 cursor-not-allowed opacity-50'
          }`}
          title="Agregar Marcador (Bandera)"
        >
          <Flag size={24} />
        </button>

        {/* Play/Pause/Stop Controls */}
        {status === RecordingStatus.RECORDING ? (
          <button 
            onClick={pauseRecording}
            className="p-6 bg-stone-900 dark:bg-white text-white dark:text-black rounded-full hover:scale-105 transition-transform shadow-lg"
          >
            <Pause size={32} fill="currentColor" />
          </button>
        ) : (
          <button 
            onClick={resumeRecording}
            className="p-6 bg-stone-900 dark:bg-white text-white dark:text-black rounded-full hover:scale-105 transition-transform shadow-lg"
          >
            <Play size={32} fill="currentColor" />
          </button>
        )}

        <button 
          onClick={stopRecording}
          className="p-6 bg-primary hover:bg-primary-hover text-white rounded-full hover:scale-105 transition-transform shadow-lg shadow-primary/30"
        >
          <Square size={32} fill="currentColor" />
        </button>

      </div>

      <div className="mt-8 text-sm text-stone-500 dark:text-stone-400 font-medium">
        {status === RecordingStatus.RECORDING ? (
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
            Grabando en curso...
          </span>
        ) : (
          <span>Grabación pausada</span>
        )}
      </div>

      {/* Markers List Preview */}
      {markers.length > 0 && (
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {markers.map(m => (
            <span key={m.id} className="px-3 py-1 bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-200 text-xs rounded-full flex items-center gap-1 border border-stone-300 dark:border-stone-600">
              <Flag size={10} /> {formatTime(m.timestamp)}
            </span>
          ))}
        </div>
      )}
      
      <button 
        onClick={onCancel} 
        className="mt-12 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 underline text-sm"
      >
        Cancelar grabación
      </button>
    </div>
  );
};

export default Recorder;