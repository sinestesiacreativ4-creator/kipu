import { GoogleGenAI, Type } from "@google/genai";
import { AIAnalysis } from "../types";

const API_KEY = process.env.API_KEY || '';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const analyzeAudio = async (base64Audio: string, markersCount: number): Promise<AIAnalysis> => {
  if (!API_KEY) {
    throw new Error("Falta la API Key.");
  }

  const model = 'gemini-2.5-flash';

  // Updated prompt context for "Asesorías Étnicas"
  const prompt = `
    Actúa como un asistente experto en documentación para "Asesorías Étnicas", una organización dedicada a apoyar comunidades indígenas y preservar su cultura.
    Recibirás una grabación de audio de una reunión, entrevista, clase o consejo comunitario.
    
    Por favor, procesa el audio y devuelve una respuesta JSON estructurada con:
    1. Un título conciso y relevante para la grabación (en Español).
    2. Un resumen de los puntos clave (array de strings).
    3. Tareas pendientes o compromisos detectados (Action Items).
    4. Una categoría (ej. "Asamblea", "Legal", "Cultural", "Territorio", "Educación").
    5. Etiquetas relevantes (Hashtags).
    6. Una transcripción completa identificando a los hablantes (Hablante A, Hablante B) y marcas de tiempo aproximadas.
    
    El usuario marcó ${markersCount} momentos importantes durante la grabación; presta especial atención a esos segmentos si son detectables.
    Asegúrate de que el tono sea respetuoso y profesional.
  `;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'audio/webm', // Assuming MediaRecorder API output
              data: base64Audio
            }
          },
          {
            text: prompt
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            category: { type: Type.STRING },
            tags: { type: Type.ARRAY, items: { type: Type.STRING } },
            summary: { type: Type.ARRAY, items: { type: Type.STRING } },
            actionItems: { type: Type.ARRAY, items: { type: Type.STRING } },
            transcript: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  speaker: { type: Type.STRING },
                  text: { type: Type.STRING },
                  timestamp: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    return JSON.parse(text) as AIAnalysis;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};