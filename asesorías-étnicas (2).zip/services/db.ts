import { UserProfile, Recording } from '../types';

const DB_NAME = 'AsesoriasEtnicasDB';
const DB_VERSION = 1;
const STORE_PROFILES = 'profiles';
const STORE_RECORDINGS = 'recordings';

export const db = {
  async open(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      
      request.onsuccess = () => resolve(request.result);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Create Profiles Store
        if (!db.objectStoreNames.contains(STORE_PROFILES)) {
          db.createObjectStore(STORE_PROFILES, { keyPath: 'id' });
        }

        // Create Recordings Store
        if (!db.objectStoreNames.contains(STORE_RECORDINGS)) {
          const store = db.createObjectStore(STORE_RECORDINGS, { keyPath: 'id' });
          // Create index to search recordings by userId
          store.createIndex('userId', 'userId', { unique: false });
        }
      };
    });
  },

  async getProfiles(): Promise<UserProfile[]> {
    const database = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_PROFILES, 'readonly');
      const store = transaction.objectStore(STORE_PROFILES);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  },

  async addProfile(profile: UserProfile): Promise<void> {
    const database = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_PROFILES, 'readwrite');
      const store = transaction.objectStore(STORE_PROFILES);
      const request = store.put(profile);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async getRecordings(userId: string): Promise<Recording[]> {
    const database = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_RECORDINGS, 'readonly');
      const store = transaction.objectStore(STORE_RECORDINGS);
      const index = store.index('userId');
      const request = index.getAll(userId);

      request.onsuccess = () => {
        // Sort by newest first
        const results = request.result as Recording[];
        results.sort((a, b) => b.createdAt - a.createdAt);
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  },

  async saveRecording(recording: Recording): Promise<void> {
    const database = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_RECORDINGS, 'readwrite');
      const store = transaction.objectStore(STORE_RECORDINGS);
      const request = store.put(recording);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  },

  async deleteRecording(id: string): Promise<void> {
    const database = await this.open();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(STORE_RECORDINGS, 'readwrite');
      const store = transaction.objectStore(STORE_RECORDINGS);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }
};